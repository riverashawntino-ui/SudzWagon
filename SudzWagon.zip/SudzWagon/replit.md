# Stay Fresh Mobile Laundry - Laundry Service Platform

## Overview

Stay Fresh Mobile Laundry is a professional mobile laundry service web application that allows customers to book laundry pickup and delivery services. The platform features a modern dark-themed interface with comprehensive booking forms, pricing information, service area details, and contact functionality. Built as a full-stack application with a React frontend and Express backend, it provides a seamless experience for customers to schedule laundry services with real-time booking management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern component development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Framework**: Radix UI components with shadcn/ui design system for accessible, customizable components
- **Styling**: Tailwind CSS with custom dark theme variables and responsive design
- **Form Handling**: React Hook Form with Zod validation for type-safe form management
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API development
- **Language**: TypeScript for full-stack type safety
- **Storage**: In-memory storage with interface abstraction (MemStorage class) for booking requests and user data
- **API Design**: RESTful endpoints for booking management with proper error handling and validation
- **Development Setup**: Hot module replacement and development middleware integration

### Database Schema Design
- **ORM**: Drizzle ORM configured for PostgreSQL with type-safe database operations
- **Schema**: Defined tables for users and booking requests with proper relationships
- **Validation**: Zod schemas for runtime type validation matching database structure
- **Tables**:
  - `users`: User authentication and profile data
  - `booking_requests`: Comprehensive booking information including contact details, service preferences, and status tracking

### Component Architecture
- **Design System**: shadcn/ui components with consistent theming and accessibility
- **Layout**: Modular component structure with Header, Hero, Pricing, Service Areas, Booking Form, and Footer sections
- **Forms**: Controlled components with comprehensive validation and error handling
- **Responsive Design**: Mobile-first approach with breakpoint-specific layouts

### Development Workflow
- **Monorepo Structure**: Client and server code in separate directories with shared schema definitions
- **Path Mapping**: TypeScript path aliases for clean imports and better code organization
- **Environment**: Development and production configurations with appropriate optimizations
- **Code Quality**: ESLint and TypeScript strict mode for code consistency and error prevention

## External Dependencies

### Core Runtime Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection for cloud deployment
- **drizzle-orm**: Type-safe ORM for database operations and query building
- **express**: Web application framework for RESTful API development
- **react**: Frontend UI library for component-based user interfaces

### UI and Styling Libraries
- **@radix-ui/**: Comprehensive set of accessible UI primitives (accordion, dialog, form controls, navigation)
- **tailwindcss**: Utility-first CSS framework for rapid UI development
- **class-variance-authority**: Component variant management for consistent styling
- **lucide-react**: Modern icon library for UI elements

### Form and Validation
- **react-hook-form**: Performant form library with minimal re-renders
- **@hookform/resolvers**: Integration layer for validation libraries
- **zod**: Runtime type validation and schema definition
- **drizzle-zod**: Automatic Zod schema generation from Drizzle database schemas

### Development and Build Tools
- **vite**: Fast build tool and development server with HMR support
- **@vitejs/plugin-react**: React integration for Vite build system
- **tsx**: TypeScript execution environment for Node.js development
- **esbuild**: Fast JavaScript bundler for production builds

### State Management and Data Fetching
- **@tanstack/react-query**: Server state management with caching, synchronization, and background updates
- **wouter**: Minimalist client-side routing solution

### Additional Utilities
- **date-fns**: Date manipulation and formatting utilities
- **clsx**: Conditional className utility for dynamic styling
- **nanoid**: URL-safe unique ID generation for client-side use
- **connect-pg-simple**: PostgreSQL session store for Express sessions