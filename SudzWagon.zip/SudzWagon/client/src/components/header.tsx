import { Phone, Shirt } from "lucide-react";

export default function Header() {
  return (
    <header className="sticky top-0 bg-dark-secondary/95 backdrop-blur-sm border-b border-border-dark z-50">
      <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Shirt className="text-warm-accent text-2xl" size={32} />
          <h1 className="text-xl font-bold text-text-primary">Stay Fresh Mobile Laundry</h1>
        </div>
        <a
          href="tel:+17195081315"
          className="bg-warm-accent hover:bg-orange-500 text-white px-6 py-3 rounded-full font-semibold transition-all duration-200 flex items-center space-x-2 shadow-lg hover:shadow-warm-accent/30"
        >
          <Phone size={16} />
          <span className="hidden sm:inline">Call Now</span>
          <span className="sm:hidden">(719) 508-1315</span>
        </a>
      </div>
    </header>
  );
}