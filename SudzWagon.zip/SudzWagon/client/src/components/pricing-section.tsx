import { Check } from "lucide-react";

export default function PricingSection() {
  const pricingTiers = [
    {
      name: "Standard Service",
      price: "$1.75",
      description: "Perfect for everyday laundry",
      features: [
        "Basic wash & fold",
        "Strong detergents",
        "24-48 hour turnaround", 
        "Free pickup & drop-off"
      ],
      isPopular: false
    },
    {
      name: "Premium Service",
      price: "$2.50",
      description: "Enhanced care for your clothes",
      features: [
        "Everything in Standard",
        "Fabric softener included",
        "Stain treatment",
        "Item-by-item attention",
        "Faster care"
      ],
      isPopular: true
    },
    {
      name: "Express Service",
      price: "$3.50",
      description: "Rush orders & urgent needs",
      features: [
        "4-6 hour turnaround",
        "Priority processing",
        "Same-day delivery",
        "Premium care included"
      ],
      isPopular: false
    }
  ];

  const additionalServices = [
    { name: "Comforters", price: "$15-$18", unit: "Queen/King size" },
    { name: "Ironing", price: "$6.00", unit: "Per garment" },
    { name: "Sleeping Bags", price: "$12.00", unit: "Each or 2 for $20" }
  ];

  const addOnOptions = [
    { name: "Fragrance-Free Detergent", price: "Free", unit: "By request only" },
    { name: "Extra Stain Treatment", price: "Included", unit: "In Premium service" },
    { name: "Weekly Subscriptions", price: "Ask for pricing", unit: "VIP pricing for loyal customers" }
  ];

  return (
    <section id="pricing" className="py-16 px-4 bg-dark-secondary">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Transparent Pricing</h2>
          <p className="text-text-secondary text-lg">No hidden fees. Pay only for what you need.</p>
        </div>

        {/* Main Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {pricingTiers.map((tier, index) => (
            <div
              key={index}
              className={`bg-dark-surface p-8 rounded-xl transition-all duration-200 relative ${
                tier.isPopular
                  ? "border-2 border-warm-accent"
                  : "border border-border-dark hover:border-warm-accent/50"
              }`}
            >
              {tier.isPopular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-warm-accent text-white px-4 py-1 rounded-full text-sm font-semibold">
                    Most Popular
                  </span>
                </div>
              )}
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold mb-2">{tier.name}</h3>
                <div className="text-3xl font-bold text-warm-accent mb-2">
                  {tier.price}<span className="text-lg text-text-secondary">/lb</span>
                </div>
                <p className="text-text-secondary">{tier.description}</p>
              </div>
              <ul className="space-y-3 mb-8 text-text-secondary">
                {tier.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center">
                    <Check className="text-green-500 mr-3" size={16} />
                    {feature}
                  </li>
                ))}
              </ul>
              <a
                href="tel:+17195081315"
                className="w-full bg-warm-accent hover:bg-orange-500 text-white py-3 rounded-lg font-semibold transition-all duration-200 block text-center"
              >
                Order Now
              </a>
            </div>
          ))}
        </div>

        {/* Specialty Items */}
        <div className="bg-dark-surface p-8 rounded-xl border border-border-dark mb-8">
          <h3 className="text-2xl font-bold mb-6 text-center">🛏 Specialty Items (Flat Fees)</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {additionalServices.map((service, index) => (
              <div key={index} className="text-center">
                <div className="text-xl font-bold text-warm-accent mb-1">{service.price}</div>
                <div className="font-semibold mb-2">{service.name}</div>
                <div className="text-sm text-text-secondary">{service.unit}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Pickup & Delivery Info */}
        <div className="bg-dark-surface p-8 rounded-xl border border-border-dark mb-8">
          <h3 className="text-2xl font-bold mb-6 text-center">🚚 Pickup & Delivery Info</h3>
          <div className="text-center space-y-3">
            <p className="text-lg font-semibold text-warm-accent">FREE pickup & drop-off included</p>
            <p className="text-text-secondary">Minimum order: 10 lbs</p>
            <p className="text-text-secondary">Express orders must be confirmed ahead of time</p>
          </div>
        </div>

        {/* Add-On Options */}
        <div className="bg-dark-surface p-8 rounded-xl border border-border-dark">
          <h3 className="text-2xl font-bold mb-6 text-center">🔥 Add-On Options</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {addOnOptions.map((addon, index) => (
              <div key={index} className="text-center">
                <div className="text-xl font-bold text-warm-accent mb-1">{addon.price}</div>
                <div className="font-semibold mb-2">{addon.name}</div>
                <div className="text-sm text-text-secondary">{addon.unit}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}