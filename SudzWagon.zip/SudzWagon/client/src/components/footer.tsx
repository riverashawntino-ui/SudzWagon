import { Shirt, Phone, Mail, MapPin, Calendar } from "lucide-react";
import { FaFacebook, FaInstagram, FaGoogle } from "react-icons/fa";

export default function Footer() {
  const scrollToBooking = () => {
    const bookingSection = document.getElementById('booking');
    if (bookingSection) {
      bookingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-dark-primary py-12 px-4 border-t border-border-dark">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <Shirt className="text-warm-accent text-2xl" size={32} />
              <h3 className="text-xl font-bold">Stay Fresh Mobile Laundry</h3>
            </div>
            <p className="text-text-secondary mb-4">
              Professional mobile laundry service bringing convenience to your doorstep.
              Quality care for your clothes with eco-friendly practices.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-warm-accent hover:text-warm-secondary transition-colors">
                <FaFacebook className="text-xl" />
              </a>
              <a href="#" className="text-warm-accent hover:text-warm-secondary transition-colors">
                <FaInstagram className="text-xl" />
              </a>
              <a href="#" className="text-warm-accent hover:text-warm-secondary transition-colors">
                <FaGoogle className="text-xl" />
              </a>
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Information</h4>
            <div className="space-y-3 text-text-secondary">
              <div className="flex items-center space-x-3">
                <Phone className="text-warm-accent" size={16} />
                <a href="tel:+17195081315" className="hover:text-warm-accent transition-colors">
                  (719) 508-1315
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="text-warm-accent" size={16} />
                <a href="mailto:hello@stayfreshmobile.com" className="hover:text-warm-accent transition-colors">
                  hello@stayfreshmobile.com
                </a>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="text-warm-accent mt-1" size={16} />
                <span>
                  Serving Metro Area<br />
                  15-mile service radius
                </span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Actions</h4>
            <div className="space-y-3">
              <a
                href="tel:+17195081315"
                className="block w-full bg-warm-accent hover:bg-orange-500 text-white py-3 px-4 rounded-lg font-semibold transition-all duration-200 text-center"
              >
                <Phone className="mr-2 inline" size={16} />
                Call for Immediate Service
              </a>
              <button
                onClick={scrollToBooking}
                className="block w-full bg-transparent border border-warm-secondary text-warm-secondary hover:bg-warm-secondary hover:text-dark-primary py-3 px-4 rounded-lg font-semibold transition-all duration-200 text-center"
              >
                <Calendar className="mr-2 inline" size={16} />
                Schedule Online
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-border-dark mt-8 pt-8 text-center text-text-secondary">
          <p>&copy; 2024 Stay Fresh Mobile Laundry. All rights reserved. | Licensed & Insured</p>
        </div>
      </div>
    </footer>
  );
}