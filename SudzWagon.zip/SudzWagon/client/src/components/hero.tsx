import { Phone, Clock, Truck, Star } from "lucide-react";

export default function Hero() {
  const scrollToBooking = () => {
    const bookingSection = document.getElementById('booking');
    if (bookingSection) {
      bookingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="bg-gradient-to-br from-dark-secondary via-dark-primary to-dark-secondary py-16 px-4">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
          Professional Mobile <span className="text-warm-accent">Laundry Service</span>
        </h2>
        <p className="text-xl text-text-secondary mb-8 max-w-2xl mx-auto">
          We Pick Up. We Wash. We Drop Off. You Stay Fresh.{" "}
          <span className="text-warm-secondary font-semibold">Starting at just $1.75/lb</span>
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <a
            href="tel:+17195081315"
            className="bg-warm-accent hover:bg-orange-500 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-200 flex items-center space-x-3 shadow-lg hover:shadow-warm-accent/30 w-full sm:w-auto justify-center"
          >
            <Phone size={20} />
            <span>Call (719) 508-1315</span>
          </a>
          <button
            onClick={scrollToBooking}
            className="bg-transparent border-2 border-warm-secondary text-warm-secondary hover:bg-warm-secondary hover:text-dark-primary px-8 py-4 rounded-full text-lg font-semibold transition-all duration-200 w-full sm:w-auto text-center"
          >
            Quick Quote
          </button>
        </div>

        {/* Service Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
          <div className="bg-dark-surface p-6 rounded-xl border border-border-dark">
            <Clock className="text-warm-accent text-2xl mb-3 mx-auto" size={32} />
            <h3 className="font-semibold mb-2">Same-Day Service</h3>
            <p className="text-text-secondary text-sm">Pick up and delivery within 24 hours</p>
          </div>
          <div className="bg-dark-surface p-6 rounded-xl border border-border-dark">
            <Truck className="text-warm-accent text-2xl mb-3 mx-auto" size={32} />
            <h3 className="font-semibold mb-2">Free Pickup & Delivery</h3>
            <p className="text-text-secondary text-sm">No extra charges for convenience</p>
          </div>
          <div className="bg-dark-surface p-6 rounded-xl border border-border-dark">
            <Star className="text-warm-accent text-2xl mb-3 mx-auto" size={32} />
            <h3 className="font-semibold mb-2">Premium Care</h3>
            <p className="text-text-secondary text-sm">Eco-friendly detergents & fabric care</p>
          </div>
        </div>
      </div>
    </section>
  );
}