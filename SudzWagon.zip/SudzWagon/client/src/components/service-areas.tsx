import { MapPin, Clock, Check, Info, Zap } from "lucide-react";

export default function ServiceAreas() {
  const serviceAreas = [
    "Downtown Metro Area",
    "Westside Neighborhoods",
    "East Bay Districts",
    "North Shore Communities",
    "Suburban Areas (15 mile radius)"
  ];

  const businessHours = [
    { day: "Monday - Friday", hours: "7:00 AM - 8:00 PM" },
    { day: "Saturday", hours: "8:00 AM - 6:00 PM" },
    { day: "Sunday", hours: "9:00 AM - 5:00 PM" }
  ];

  return (
    <section className="py-16 px-4 bg-dark-primary">
      <div className="max-w-4xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Service Areas */}
          <div className="bg-dark-surface p-8 rounded-xl border border-border-dark">
            <h3 className="text-2xl font-bold mb-6 flex items-center">
              <MapPin className="text-warm-accent mr-3" size={24} />
              Service Areas
            </h3>
            <ul className="space-y-3 text-text-secondary">
              {serviceAreas.map((area, index) => (
                <li key={index} className="flex items-center">
                  <Check className="text-green-500 mr-3" size={16} />
                  {area}
                </li>
              ))}
            </ul>
            <div className="text-sm text-text-secondary mt-4 p-4 bg-dark-primary rounded-lg">
              <Info className="text-warm-secondary mr-2 inline" size={16} />
              Not sure if we serve your area? Call us at (719) 508-1315 to check!
            </div>
          </div>

          {/* Business Hours */}
          <div className="bg-dark-surface p-8 rounded-xl border border-border-dark">
            <h3 className="text-2xl font-bold mb-6 flex items-center">
              <Clock className="text-warm-accent mr-3" size={24} />
              Business Hours
            </h3>
            <div className="space-y-3">
              {businessHours.map((schedule, index) => (
                <div
                  key={index}
                  className="flex justify-between items-center py-2 border-b border-border-dark"
                >
                  <span className="font-semibold">{schedule.day}</span>
                  <span className="text-text-secondary">{schedule.hours}</span>
                </div>
              ))}
            </div>
            <div className="mt-6 p-4 bg-warm-accent/10 border border-warm-accent/20 rounded-lg">
              <p className="text-sm text-warm-secondary font-semibold mb-2">
                <Zap className="mr-2 inline" size={16} />
                Express Service Available
              </p>
              <p className="text-sm text-text-secondary">
                Same-day pickup and delivery available Monday-Friday before 2:00 PM
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}