import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { CalendarCheck, Phone } from "lucide-react";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

const bookingFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  email: z.string().email("Please enter a valid email").optional().or(z.literal("")),
  serviceType: z.string().min(1, "Please select a service type"),
  estimatedWeight: z.string().optional(),
  pickupAddress: z.string().min(5, "Please enter a complete pickup address"),
  pickupDate: z.string().optional(),
  pickupTime: z.string().optional(),
  specialInstructions: z.string().optional(),
  estimatedPrice: z.string().optional(),
});

type BookingFormData = z.infer<typeof bookingFormSchema>;

export default function BookingForm() {
  const [estimatedPrice, setEstimatedPrice] = useState("$17.50 - $52.50");
  const { toast } = useToast();

  const form = useForm<BookingFormData>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      name: "",
      phone: "",
      email: "",
      serviceType: "",
      estimatedWeight: "",
      pickupAddress: "",
      pickupDate: "",
      pickupTime: "",
      specialInstructions: "",
      estimatedPrice: "",
    },
  });

  const createBookingMutation = useMutation({
    mutationFn: async (data: BookingFormData) => {
      const response = await apiRequest("POST", "/api/booking-requests", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Booking Request Submitted!",
        description: "We'll call you within 30 minutes to confirm your pickup.",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit booking request. Please try again.",
        variant: "destructive",
      });
    },
  });

  const calculateEstimate = () => {
    const serviceType = form.watch("serviceType");
    const weight = form.watch("estimatedWeight");

    if (!serviceType || !weight) {
      setEstimatedPrice("$17.50 - $52.50");
      return;
    }

    const servicePrices = {
      standard: 1.75,
      premium: 2.50,
      express: 3.50,
    };

    const weightRanges = {
      "5-10": { min: 5, max: 10 },
      "10-20": { min: 10, max: 20 },
      "20-30": { min: 20, max: 30 },
      "30+": { min: 30, max: 40 },
    };

    const price = servicePrices[serviceType as keyof typeof servicePrices];
    const range = weightRanges[weight as keyof typeof weightRanges];

    if (price && range) {
      const minPrice = (range.min * price).toFixed(2);
      const maxPrice = (range.max * price).toFixed(2);
      const estimate = `$${minPrice} - $${maxPrice}`;
      setEstimatedPrice(estimate);
      form.setValue("estimatedPrice", estimate);
    }
  };

  const onSubmit = (data: BookingFormData) => {
    createBookingMutation.mutate(data);
  };

  return (
    <section id="booking" className="py-16 px-4 bg-dark-secondary">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-4">Quick Service Request</h2>
          <p className="text-text-secondary">Get an instant quote and schedule your pickup</p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="bg-dark-surface p-8 rounded-xl border border-border-dark space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">Your Name *</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="Enter your full name"
                        className="bg-dark-primary border-border-dark text-text-primary focus:border-warm-accent"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">Phone Number *</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="tel"
                        placeholder="(719) 508-1315"
                        className="bg-dark-primary border-border-dark text-text-primary focus:border-warm-accent"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="serviceType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">Service Type *</FormLabel>
                    <Select onValueChange={(value) => { field.onChange(value); calculateEstimate(); }}>
                      <FormControl>
                        <SelectTrigger className="bg-dark-primary border-border-dark text-text-primary focus:border-warm-accent">
                          <SelectValue placeholder="Select service type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-dark-surface border-border-dark">
                        <SelectItem value="standard">Standard Service ($1.75/lb)</SelectItem>
                        <SelectItem value="premium">Premium Service ($2.50/lb)</SelectItem>
                        <SelectItem value="express">Express Service ($3.50/lb)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="estimatedWeight"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">Estimated Weight</FormLabel>
                    <Select onValueChange={(value) => { field.onChange(value); calculateEstimate(); }}>
                      <FormControl>
                        <SelectTrigger className="bg-dark-primary border-border-dark text-text-primary focus:border-warm-accent">
                          <SelectValue placeholder="Select estimated weight" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-dark-surface border-border-dark">
                        <SelectItem value="5-10">5-10 lbs (~$8.75-$35)</SelectItem>
                        <SelectItem value="10-20">10-20 lbs (~$17.50-$70)</SelectItem>
                        <SelectItem value="20-30">20-30 lbs (~$35-$105)</SelectItem>
                        <SelectItem value="30+">30+ lbs (Call for quote)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="pickupAddress"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-semibold">Pickup Address *</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      placeholder="Enter your complete pickup address including apartment/unit number"
                      className="bg-dark-primary border-border-dark text-text-primary focus:border-warm-accent h-24 resize-none"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="pickupDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">Preferred Pickup Date</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="date"
                        className="bg-dark-primary border-border-dark text-text-primary focus:border-warm-accent"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="pickupTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">Preferred Time</FormLabel>
                    <Select onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger className="bg-dark-primary border-border-dark text-text-primary focus:border-warm-accent">
                          <SelectValue placeholder="Select preferred time" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent className="bg-dark-surface border-border-dark">
                        <SelectItem value="morning">Morning (8AM-12PM)</SelectItem>
                        <SelectItem value="afternoon">Afternoon (12PM-5PM)</SelectItem>
                        <SelectItem value="evening">Evening (5PM-8PM)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="specialInstructions"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-semibold">Special Instructions</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      placeholder="Any special care instructions, stain treatments needed, or delivery preferences..."
                      className="bg-dark-primary border-border-dark text-text-primary focus:border-warm-accent h-20 resize-none"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Price Estimate Display */}
            <div className="bg-warm-accent/10 border border-warm-accent/20 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-warm-secondary">Estimated Total:</span>
                <span className="text-2xl font-bold text-warm-accent">{estimatedPrice}</span>
              </div>
              <p className="text-sm text-text-secondary mt-2">
                Final price based on actual weight. No hidden fees or surprises!
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                type="submit"
                disabled={createBookingMutation.isPending}
                className="flex-1 bg-warm-accent hover:bg-orange-500 text-white py-4 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center space-x-2"
              >
                <CalendarCheck size={20} />
                <span>{createBookingMutation.isPending ? "Submitting..." : "Schedule Pickup"}</span>
              </Button>
              <a
                href="tel:+17195081315"
                className="flex-1 bg-transparent border-2 border-warm-secondary text-warm-secondary hover:bg-warm-secondary hover:text-dark-primary py-4 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center space-x-2"
              >
                <Phone size={20} />
                <span>Call Instead</span>
              </a>
            </div>
          </form>
        </Form>
      </div>
    </section>
  );
}