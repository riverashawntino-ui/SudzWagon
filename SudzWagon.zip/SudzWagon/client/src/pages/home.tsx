import Header from "@/components/header";
import Hero from "@/components/hero";
import PricingSection from "@/components/pricing-section";
import ServiceAreas from "@/components/service-areas";
import BookingForm from "@/components/booking-form";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-dark-primary">
      <Header />
      <Hero />
      <PricingSection />
      <ServiceAreas />
      <BookingForm />
      <Footer />
    </div>
  );
}
