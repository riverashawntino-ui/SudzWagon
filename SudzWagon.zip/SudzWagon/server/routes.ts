import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBookingRequestSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create booking request
  app.post("/api/booking-requests", async (req, res) => {
    try {
      const validatedData = insertBookingRequestSchema.parse(req.body);
      const bookingRequest = await storage.createBookingRequest(validatedData);
      res.json(bookingRequest);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid request data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // Get all booking requests
  app.get("/api/booking-requests", async (req, res) => {
    try {
      const requests = await storage.getAllBookingRequests();
      res.json(requests);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get single booking request
  app.get("/api/booking-requests/:id", async (req, res) => {
    try {
      const request = await storage.getBookingRequest(req.params.id);
      if (!request) {
        return res.status(404).json({ message: "Booking request not found" });
      }
      res.json(request);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
