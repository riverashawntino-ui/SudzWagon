import { type User, type InsertUser, type BookingRequest, type InsertBookingRequest } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createBookingRequest(request: InsertBookingRequest): Promise<BookingRequest>;
  getBookingRequest(id: string): Promise<BookingRequest | undefined>;
  getAllBookingRequests(): Promise<BookingRequest[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private bookingRequests: Map<string, BookingRequest>;

  constructor() {
    this.users = new Map();
    this.bookingRequests = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createBookingRequest(insertRequest: InsertBookingRequest): Promise<BookingRequest> {
    const id = randomUUID();
    const request: BookingRequest = {
      ...insertRequest,
      id,
      status: "pending",
      createdAt: new Date(),
      email: insertRequest.email || null,
      estimatedWeight: insertRequest.estimatedWeight || null,
      pickupDate: insertRequest.pickupDate || null,
      pickupTime: insertRequest.pickupTime || null,
      specialInstructions: insertRequest.specialInstructions || null,
      estimatedPrice: insertRequest.estimatedPrice || null,
    };
    this.bookingRequests.set(id, request);
    return request;
  }

  async getBookingRequest(id: string): Promise<BookingRequest | undefined> {
    return this.bookingRequests.get(id);
  }

  async getAllBookingRequests(): Promise<BookingRequest[]> {
    return Array.from(this.bookingRequests.values());
  }
}

export const storage = new MemStorage();
